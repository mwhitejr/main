#include <fstream>
#include <iostream>
#include <cctype>
#include <iomanip>	
using namespace std;

const int SIZE=91;
void PrintOccurrences(const  int[]);
int  main ()
{
    ifstream dataFile;
    int  freqCount[SIZE];
    char ch;
	  char index;
	dataFile.open ("my.dat"); // Open 
 if  (! dataFile)          // Verify success
 {
       cout  <<  " CAN’T OPEN INPUT FILE ! " 
               << endl;
       return  1;
      }
     for ( int  m = 0; m < SIZE;  m++) // Zero array
         freqCount[m]  =  0;
	// Read file one character at a time
    dataFile.get (ch);  // Priming read
    while (dataFile)	  // While read successful
     {
		  if (isalpha (ch))
		  {	
            if (islower (ch))
		          ch  =  toupper (ch);
			
			freqCount[ch]  =  freqCount[ch] + 1;
}
		  dataFile. get (ch); // Get next character
    }
	 PrintOccurrences (freqCount);
	 return  0;
}
void PrintOccurrences (
    /* in */ const int  freqCount []) 
{	
    char  index;
    cout  <<  "File contained "  << endl;
    cout  <<  "LETTER      OCCURRENCES"  << endl;
    for   ( index = 'A' ;  index <= 'Z';  index ++)
    {
        cout << setw(4) << index << setw(10)  
		 << freqCount[index] << endl;
    }
}

/*File contained
LETTER      OCCURRENCES
   A         2
   B         0
   C         1
   D         0
   E         2
   F         1
   G         1
   H         2
   I         9
   J         0
   K         0
   L         1
   M         2
   N         5
   O         2
   P         0
   Q         0
   R         0
   S         6
   T         8
   U         0
   V         0
   W         0
   X         1
   Y         2
   Z         0*/