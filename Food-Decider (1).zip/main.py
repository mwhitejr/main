import json

try:
  f = open('Huntsville.json', 'r')
  Huntsville = json.loads(f.read())
  f.close()
except IOError:
  Huntsville = []

f = open('Huntsville.json', 'w')

f.write(json.dumps(Huntsville))
f.close()

recently_chosen = []

import random
#print(random.choice(['The Melting Pot', 'New China Restaurant', 'Chow King Grill & Buffet', 'Golden Star']))
hunger = input('Are you hungry?')
while hunger == 'Yes'or 'yes':

  unwanted = input('Should we OMIT Fast Food or Dine-In?')
  wanted = input('Is it Breakfast, Lunch, or Dinner?')
  max_price = input('What is the most expensive restaurant you feel like attending?')
  while max_price != '$' and max_price != '$$' and max_price != '$$$':
    max_price = input('What is the most expensive restaurant you feel like attending? Use up to $$$ describe price range.')

  potential_restaurants = []
  for r in Huntsville:
    if unwanted not in r["tag"] and len(r["price"]) <= len(max_price) and wanted in r["tag"] and r not in recently_chosen:
      potential_restaurants.append(r)
  
  if len(potential_restaurants) == 0:
    print("Sorry, out of restaraunts.")
  else:  
    chosen = (random.choice(potential_restaurants))
    print(chosen)
    recently_chosen.append(chosen)
  hunger = input('Are you hungry?')

if len(potential_restaurants) == 0:
  print("Sorry, out of restaraunts.")