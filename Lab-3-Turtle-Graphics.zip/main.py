# Create your own drawing using turtle graphics! 
# To receive full credit, you must:
# 1. Create and use at least two functions to draw different shapes
# 2. Use a loop in your program
# 3. Use at least 5 different turtle graphics methods

import turtle

def drawMulticolorSquare(t, sz):
    for i in ['red', 'purple', 'hotpink', 'blue']:
        t.color(i)
        t.forward(sz)
        t.left(90)
        
        wn = turtle.Screen()
        wn.bgcolor("orange")
        
        tess = turtle.Turtle()
        tess.pensize(3)
        
size = 20
for i in range(15):
    tess = turtle.Turtle()
    drawMulticolorSquare(tess, size)
    size = size + 10
    tess.forward(10)
    tess.right(18)
    
wn.exitonclick()
